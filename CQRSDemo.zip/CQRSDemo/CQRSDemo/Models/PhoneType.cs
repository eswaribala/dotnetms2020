﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CQRSDemo.Models
{
    public enum PhoneType
    {
        HOMEPHONE, CELLPHONE, WORKPHONE
    }
}

﻿using CQRSApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CQRSApi.Context
{
    public class TransactionContext : DbContext, ITransactionContext
    {
        public DbSet<Transaction> Transactions { get; set; }
        public TransactionContext(DbContextOptions<TransactionContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }
       
        public async Task<long> SaveChanges()
        {
            return await base.SaveChangesAsync();
        }
    }
}

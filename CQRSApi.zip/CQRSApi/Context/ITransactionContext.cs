﻿using CQRSApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CQRSApi.Context
{
    public interface ITransactionContext
    {
        DbSet<Transaction> Transactions { get; set; }

        Task<long> SaveChanges();
    }
}
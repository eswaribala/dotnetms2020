﻿using CQRSApi.Context;
using CQRSApi.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace CQRSApi.Queries
{
    public class GetAllTransactionQuery : IRequest<IEnumerable<Transaction>>
    {
        public class GetAllTransactionQueryHandler : IRequestHandler<GetAllTransactionQuery, IEnumerable<Transaction>>
        {
            private readonly ITransactionContext _context;
            public GetAllTransactionQueryHandler(ITransactionContext context)
            {
                _context = context;
            }
            public async Task<IEnumerable<Transaction>> Handle(GetAllTransactionQuery query, CancellationToken cancellationToken)
            {
                var transactionList = await _context.Transactions.ToListAsync();
                if (transactionList == null)
                {
                    return null;
                }
                return transactionList.AsReadOnly();
            }
        }
    }
}

﻿using CQRSApi.Context;
using CQRSApi.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CQRSApi.Queries
{
    public class GetTransactionByIdQuery : IRequest<Transaction>
    {
        public long Id { get; set; }
        public class GetTransactionByIdQueryHandler : IRequestHandler<GetTransactionByIdQuery, Transaction>
        {
            private readonly ITransactionContext _context;
            public GetTransactionByIdQueryHandler(ITransactionContext context)
            {
                _context = context;
            }
            public async Task<Transaction> Handle(GetTransactionByIdQuery query, CancellationToken cancellationToken)
            {
                var transaction = _context.Transactions.Where(a => a.TransactionId == query.Id).FirstOrDefault();
                if (transaction == null) return null;
                return transaction;
            }
        }
    }
}

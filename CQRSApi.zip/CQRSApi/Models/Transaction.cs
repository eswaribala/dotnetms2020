﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CQRSApi.Models
{
    public class Transaction
    {
        public long TransactionId { get; set; }
        public String Type { get; set; }
        public DateTime DOT { get; set; }
        public long Amount { get; set; }
    }
}

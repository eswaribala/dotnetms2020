﻿using CQRSApi.Context;
using CQRSApi.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CQRSApi.Commands
{
    public class UpdateTransactionCommand : IRequest<long>
    {
        public long TransactionId { get; set; }
        public String Type { get; set; }
        public DateTime DOT { get; set; }
        public long Amount { get; set; }
        public class UpdateTransactionCommandHandler : IRequestHandler<UpdateTransactionCommand, long>
        {
            private readonly ITransactionContext _context;
            public UpdateTransactionCommandHandler(ITransactionContext context)
            {
                _context = context;
            }
            public async Task<long> Handle(UpdateTransactionCommand command, CancellationToken cancellationToken)
            {
                var transaction = _context.Transactions.Where(a => a.TransactionId == command.TransactionId).FirstOrDefault();

                if (transaction == null)
                {
                    return default;
                }
                else
                {
                    transaction.TransactionId = command.TransactionId;
                    transaction.DOT = command.DOT;
                    transaction.Amount = command.Amount;
                    transaction.Type = command.Type;
                    await _context.SaveChanges();
                    return transaction.TransactionId;
                }
            }
        }
    }
}

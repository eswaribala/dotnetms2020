﻿using CQRSApi.Context;
using CQRSApi.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CQRSApi.Commands
{
    public class CreateTransactionCommand : IRequest<long>
    {
        public long TransactionId { get; set; }
        public String Type { get; set; }
        public DateTime DOT { get; set; }
        public long Amount { get; set; }
        public class CreateTransactionCommandHandler : IRequestHandler<CreateTransactionCommand, long>
        {
            private readonly ITransactionContext _context;
            public CreateTransactionCommandHandler(ITransactionContext context)
            {
                _context = context;
            }
            public async Task<long> Handle(CreateTransactionCommand command, CancellationToken cancellationToken)
            {
                var transaction = new Transaction();
                transaction.TransactionId = command.TransactionId;
                transaction.Type = command.Type;
                transaction.DOT = command.DOT;
                transaction.Amount = command.Amount;
                


                _context.Transactions.Add(transaction);
                await _context.SaveChanges();
                return transaction.TransactionId;
            }
        }
    }
}

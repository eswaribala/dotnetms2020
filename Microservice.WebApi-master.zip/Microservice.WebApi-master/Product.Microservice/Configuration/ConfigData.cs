﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Product.Microservice.Configuration
{
    public class ConfigData
{
    public string ServiceUrl { get; set; } 
}
}
